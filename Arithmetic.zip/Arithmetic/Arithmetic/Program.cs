﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Arithmetic
{
    class Program
    {
        static void Main(string[] args)
        {
            int n1, n2, n3, n4, n5, n6, n7, n8, sum, sub, muti, div;

            Console.Write("Enetr Number 1:");
            n1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enetr Number 2:");
            n2 = Convert.ToInt32(Console.ReadLine());
            sum = n1 + n2;
            Console.WriteLine("sum is : " + sum);
            Console.ReadLine();

            Console.Write("Enetr Number 3:");
            n3 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enetr Number 4:");
            n4 = Convert.ToInt32(Console.ReadLine());
            sum = n3 - n4;
            Console.WriteLine("sub is : " + sum);
            Console.ReadLine();

            Console.Write("Enetr Number 5:");
            n5 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enetr Number 6:");
            n6 = Convert.ToInt32(Console.ReadLine());
            sum = n5 * n6;
            Console.WriteLine("muti is : " + sum);
            Console.ReadLine();

            Console.Write("Enetr Number 7:");
            n7 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enetr Number 8:");
            n8 = Convert.ToInt32(Console.ReadLine());
            sum = n7/ n8;
            Console.WriteLine("div is : " + sum);
            Console.ReadLine();
        }
    }
}
